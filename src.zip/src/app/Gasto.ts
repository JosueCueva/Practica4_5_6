export interface Gasto{
    "id":number,
    "tipo":string,
    "ruc":string,
    "valor":Float32Array;
}