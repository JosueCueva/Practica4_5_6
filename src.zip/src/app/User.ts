export interface User{
    "userid":number;
    "name":string;
    "username":string;
    "email":string;
}