import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ContactoComponent } from './contacto/contacto.component';
import { HomeComponent } from './home/home.component';
import { InformacionComponent } from './informacion/informacion.component';
import { FormularioComponent } from './formulario/formulario.component';
import { ReporteComponent } from './reporte/reporte.component';
import { MenuComponent } from './menu/menu.component';
import { RouterLinkActive } from '@angular/router';
import { UsuariosComponent } from './usuarios/usuarios.component';

const routes: Routes = [
  { path: '', component: HomeComponent},
  { path: 'contacto', component: ContactoComponent},
  { path: 'informacion', component: InformacionComponent},
  { path: 'registro', component: FormularioComponent},
  { path: 'menu', component: MenuComponent},
  { path: 'reporte', component: ReporteComponent},
  { path: 'usuarios', component: UsuariosComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
