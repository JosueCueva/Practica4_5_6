import { Component } from '@angular/core';

@Component({
  selector: 'formulario',
  templateUrl: './formulario.component.html',
  styleUrls: ['./formulario.component.css']
})
export class FormularioComponent {
  constructor() { }
  ngOnInit():void {}
  ruc:string='99999999001';
  valor:number=0.0;;
  gasto:string='Ninguno';

  guardarDatos(){
    console.log({"ruc":this.ruc,"valor":this.valor,"gasto":this.gasto});
  }
}
