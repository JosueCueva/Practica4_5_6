import { Component } from '@angular/core';

@Component({
  selector: 'app-informacion',
  templateUrl: './informacion.component.html',
  styleUrls: ['./informacion.component.css']
})
export class InformacionComponent {
  constructor() {}

  ngOnInit(): void {}
  deducibles = [
    {
      nombre: 'Vivienda',
      imagen: './assets/Vivienda.png',
    },
    {
      nombre: 'Salud',
      imagen: './assets/Salud.png',
    },
    {
      nombre: 'Educacion',
      imagen: './assets/Educacion.jpeg',
    },
  ];
  informacion(deducible:string) {
    alert('Esta es información adicional sobre ' + deducible);
  }
  borrarDeducible(deducible: string) {
    for (let i = 0; i < this.deducibles.length; i++) {
      if (deducible == this.deducibles[i].nombre) {
        this.deducibles.splice(i, 1);
      }
    }
  }
}
