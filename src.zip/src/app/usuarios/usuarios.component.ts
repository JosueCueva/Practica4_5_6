import { Component } from '@angular/core';
import { UserService } from '../user.service';
import { User } from '../User';

@Component({
  selector: 'app-usuarios',
  templateUrl: './usuarios.component.html',
  styleUrls: ['./usuarios.component.css']
})
export class UsuariosComponent {
  users:User[]=[];
  constructor(private userService:UserService){
    this.userService.obtenerDatos().subscribe(data =>
      {
      console.log(data);
      this.users=data;
      });
  }
}
